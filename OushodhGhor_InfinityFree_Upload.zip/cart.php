<?php
require_once __DIR__ . '/includes/functions.php';
$products = get_products();
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$items = [];
$total = 0;
foreach ($cart as $id => $qty) {
    foreach ($products as $p) {
        if ($p['id'] === $id) { $items[] = array_merge($p, ['qty' => $qty]); $total += $p['price'] * $qty; break; }
    }
}
$BASE = '';
include __DIR__ . '/includes/header.php';
?>
<h1 class="page-title">আপনার কার্ট</h1>
<?php if (empty($items)): ?>
  <div class="empty-state">
    <p>আপনার কার্ট খালি — পছন্দের পণ্য যোগ করুন।</p>
    <a href="index.php" class="btn btn-primary">কেনাকাটা করুন</a>
  </div>
<?php else: ?>
<div class="cart-list">
  <?php foreach ($items as $it): ?>
    <div class="cart-item">
      <div class="cart-item-thumb"><?php echo product_image_html($it, 56); ?></div>
      <div class="cart-item-info">
        <div class="cart-item-name"><?php echo htmlspecialchars($it['name']); ?></div>
        <div class="cart-item-price"><?php echo taka($it['price']); ?></div>
      </div>
      <div class="qty-control">
        <a href="update-cart.php?id=<?php echo urlencode($it['id']); ?>&action=dec" class="qty-btn">−</a>
        <span><?php echo $it['qty']; ?></span>
        <a href="update-cart.php?id=<?php echo urlencode($it['id']); ?>&action=inc" class="qty-btn">+</a>
      </div>
      <a href="update-cart.php?id=<?php echo urlencode($it['id']); ?>&action=remove" class="remove-link">মুছুন</a>
    </div>
  <?php endforeach; ?>
</div>
<div class="cart-total-row">
  <span>মোট মূল্য</span>
  <strong><?php echo taka($total); ?></strong>
</div>
<a href="checkout.php" class="btn btn-primary btn-block">চেকআউট করুন</a>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
