<?php
require_once __DIR__ . '/functions.php';
$BASE = isset($BASE) ? $BASE : '';
$__isAdminPage = ($BASE === '../');
$__cartCount = 0;
if (!empty($_SESSION['cart'])) { foreach ($_SESSION['cart'] as $__q) $__cartCount += $__q; }
?><!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo h(SITE_NAME); ?> — অনলাইন মেডিসিন শপ</title>
<?php if ($__isAdminPage): ?><meta name="robots" content="noindex,nofollow"><?php endif; ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Tiro+Bangla&family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo $BASE; ?>assets/style.css">
<script>
(function () {
  var saved = localStorage.getItem('theme');
  var theme = saved ? saved : ((window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', theme);
})();
</script>
</head>
<body>
<header class="site-header">
  <div class="container header-row">
    <a href="<?php echo $BASE; ?>index.php" class="logo">
      <span class="logo-badge">💊</span>
      <span class="logo-text"><?php echo h(SITE_NAME); ?></span>
    </a>
    <div class="spacer"></div>
    <button id="themeToggle" type="button" class="icon-btn theme-toggle-btn" title="নাইট মোড চালু/বন্ধ করুন">🌙</button>
    <?php if ($__isAdminPage): ?>
      <a href="<?php echo $BASE; ?>index.php" class="icon-btn" title="দোকান দেখুন">🏪</a>
    <?php else: ?>
      <a href="<?php echo $BASE; ?>track.php" class="icon-btn" title="অর্ডার ট্র্যাক করুন">📦</a>
      <a href="<?php echo $BASE; ?>cart.php" class="icon-btn cart-btn" title="কার্ট">
        🛒<?php if ($__cartCount > 0): ?><span class="badge"><?php echo $__cartCount; ?></span><?php endif; ?>
      </a>
    <?php endif; ?>
  </div>
</header>
<script>
(function () {
  var btn = document.getElementById('themeToggle');
  function setIcon(theme) { btn.textContent = theme === 'dark' ? '☀️' : '🌙'; }
  setIcon(document.documentElement.getAttribute('data-theme') || 'light');
  btn.addEventListener('click', function () {
    var current = document.documentElement.getAttribute('data-theme') || 'light';
    var next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
    setIcon(next);
  });
})();
</script>
<main class="container main-content">
