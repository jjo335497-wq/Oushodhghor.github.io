</main>
<footer class="site-footer">
  <?php $__s = get_settings(); if (!empty($__s['contact_phone'])): ?>
  <p>যেকোনো প্রয়োজনে যোগাযোগ করুন: <strong><?php echo h($__s['contact_phone']); ?></strong></p>
  <?php endif; ?>
  <p>© <?php echo h(SITE_NAME); ?> — বিশ্বস্ত অনলাইন মেডিসিন শপ</p>
</footer>
</body>
</html>
