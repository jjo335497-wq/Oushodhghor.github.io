<?php
date_default_timezone_set('Asia/Dhaka');

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    ]);
    session_start();
}

define('SITE_NAME', 'OushodhGhor');
define('DATA_DIR', __DIR__ . '/../data');
define('UPLOAD_DIR', __DIR__ . '/../uploads');
// Every data file starts with this line, so even if a server ignores .htaccess,
// opening the file in a browser only shows a 404 and never the customer data.
define('DATA_GUARD', "<?php http_response_code(404); exit; ?>\n");

function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/* ---------------- data storage (file locked) ---------------- */
function data_path($name) { return DATA_DIR . '/' . $name . '.data.php'; }

function parse_data($raw) {
    if (strpos($raw, DATA_GUARD) === 0) $raw = substr($raw, strlen(DATA_GUARD));
    $d = json_decode($raw, true);
    return is_array($d) ? $d : [];
}

function read_json($name) {
    $path = data_path($name);
    if (!file_exists($path)) return [];
    $fp = fopen($path, 'r');
    if (!$fp) return [];
    flock($fp, LOCK_SH);
    $raw = stream_get_contents($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return parse_data($raw);
}

/* Read -> change -> write while holding one exclusive lock, so two people
   ordering at the same moment can never overwrite each other. */
function update_json($name, $fn) {
    $fp = fopen(data_path($name), 'c+');
    if (!$fp) return false;
    flock($fp, LOCK_EX);
    $raw = stream_get_contents($fp);
    $data = $fn(parse_data($raw));
    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, DATA_GUARD . json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return $data;
}

function get_products() { return read_json('products'); }
function get_orders()   { return read_json('orders'); }

function get_settings() {
    $defaults = ['admin_phone' => '', 'contact_phone' => '', 'admin_password_hash' => ''];
    return array_merge($defaults, read_json('settings'));
}

function find_product($id) {
    foreach (get_products() as $p) { if ($p['id'] === $id) return $p; }
    return null;
}

/* ---------------- display helpers ---------------- */
function taka($n) {
    return '৳' . number_format((float)$n, ((float)$n == (int)$n) ? 0 : 2);
}

function fmt_time($s) { return $s ? date('d/m/Y h:i A', strtotime($s)) : ''; }

function category_list() {
    return [
        'fever'      => ['name' => 'জ্বর ও ব্যথা',          'color' => '#B24438'],
        'cold'       => ['name' => 'সর্দি-কাশি',            'color' => '#3B6E8F'],
        'vitamin'    => ['name' => 'ভিটামিন ও সাপ্লিমেন্ট',  'color' => '#B8892E'],
        'baby'       => ['name' => 'শিশুর যত্ন',             'color' => '#A2678A'],
        'skin'       => ['name' => 'ত্বক ও প্রসাধনী',        'color' => '#4B8B7A'],
        'diabetes'   => ['name' => 'ডায়াবেটিস কেয়ার',       'color' => '#6B5CA5'],
        'firstaid'   => ['name' => 'প্রাথমিক চিকিৎসা',       'color' => '#1F4B43'],
        'protection' => ['name' => 'ব্যক্তিগত সুরক্ষা',       'color' => '#7A8B4B'],
    ];
}

function status_labels() {
    return [
        'pending'    => 'অপেক্ষমাণ',
        'processing' => 'প্রক্রিয়াধীন',
        'shipped'    => 'ডেলিভারি ম্যানের হাতে',
        'delivered'  => 'ডেলিভারি সম্পন্ন',
        'cancelled'  => 'বাতিল',
    ];
}

function track_steps() {
    return [
        ['pending',    'অর্ডার গ্রহণ করা হয়েছে', 'আপনার অর্ডার আমরা পেয়েছি'],
        ['processing', 'প্যাকেজিং চলছে',          'পণ্য প্রস্তুত করা হচ্ছে'],
        ['shipped',    'ডেলিভারি ম্যানের হাতে',   'পণ্য আপনার ঠিকানার পথে'],
        ['delivered',  'ডেলিভারি সম্পন্ন',         'পণ্য পৌঁছে গেছে'],
    ];
}

function order_step_time($order, $key) {
    if ($key === 'pending') return fmt_time($order['created_at']);
    $t = '';
    if (!empty($order['history'])) {
        foreach ($order['history'] as $hh) { if ($hh['status'] === $key) $t = $hh['at']; }
    }
    return fmt_time($t);
}

/* Shows the uploaded photo, or a neat letter tile when there is none */
function product_image_html($product, $size = 80) {
    $cats = category_list();
    $cat = isset($cats[$product['category']]) ? $cats[$product['category']] : ['name' => '', 'color' => '#1F4B43'];
    if (!empty($product['image']) && file_exists(UPLOAD_DIR . '/' . $product['image'])) {
        $src = 'uploads/' . rawurlencode($product['image']);
        if (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) $src = '../' . $src;
        return '<img src="' . $src . '" alt="' . h($product['name']) . '" style="width:100%;height:100%;object-fit:cover;border-radius:12px;">';
    }
    $letter = mb_substr($product['name'], 0, 1, 'UTF-8');
    $fontSize = round($size * 0.42);
    return '<div style="width:100%;height:100%;border-radius:12px;background:' . $cat['color'] . '1A;display:flex;align-items:center;justify-content:center;color:' . $cat['color'] . ';font-family:\'Tiro Bangla\',serif;font-size:' . $fontSize . 'px;">' . h($letter) . '</div>';
}

/* ---------------- validation ---------------- */
function normalize_phone($p) {
    $bn = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    $en = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    $p = str_replace($bn, $en, (string)$p);
    $p = preg_replace('/[\s\-()]/u', '', $p);
    if (strpos($p, '+88') === 0) {
        $p = substr($p, 3);
    } elseif (strpos($p, '88') === 0 && strlen($p) === 13) {
        $p = substr($p, 2);
    }
    return $p;
}
function valid_bd_phone($p) { return (bool)preg_match('/^01[3-9][0-9]{8}$/', $p); }
function valid_person_name($n) { return (bool)preg_match('/^[\p{Bengali}A-Za-z][\p{Bengali}A-Za-z .\'-]+$/u', $n); }

/* ---------------- CSRF (blocks forged admin clicks) ---------------- */
function csrf_token() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function csrf_field() { return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">'; }
function csrf_check() {
    $ok = isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $_POST['csrf']);
    if (!$ok) {
        http_response_code(403);
        exit('অনুরোধ যাচাই করা যায়নি। পেজটি রিফ্রেশ করে আবার চেষ্টা করুন।');
    }
}

/* ---------------- admin auth ---------------- */
function is_admin() { return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true; }
function require_admin() {
    if (!is_admin()) { header('Location: login.php'); exit; }
}

function client_ip() { return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown'; }

function login_locked() {
    $a = read_json('login_attempts');
    $ip = client_ip();
    return isset($a[$ip]) && $a[$ip]['count'] >= 5 && (time() - $a[$ip]['time']) < 600;
}
function login_fail() {
    $ip = client_ip();
    update_json('login_attempts', function ($a) use ($ip) {
        if (!isset($a[$ip]) || (time() - $a[$ip]['time']) > 600) $a[$ip] = ['count' => 0, 'time' => time()];
        $a[$ip]['count']++;
        $a[$ip]['time'] = time();
        return $a;
    });
}
function login_clear() {
    $ip = client_ip();
    update_json('login_attempts', function ($a) use ($ip) { unset($a[$ip]); return $a; });
}

/* Stops one device from flooding the shop with fake orders (5 per hour) */
function order_rate_ok() {
    $ip = client_ip();
    $ok = true;
    update_json('order_limits', function ($d) use ($ip, &$ok) {
        $now = time();
        $times = isset($d[$ip]) ? array_values(array_filter($d[$ip], function ($t) use ($now) { return ($now - $t) < 3600; })) : [];
        if (count($times) >= 5) { $ok = false; } else { $times[] = $now; }
        $d[$ip] = $times;
        foreach ($d as $k => $v) { if (empty($v)) unset($d[$k]); }
        return $d;
    });
    return $ok;
}

/* ---------------- image upload (real images only) ---------------- */
function handle_image_upload($field, $oldImage = null) {
    $GLOBALS['UPLOAD_ERR'] = '';
    if (!isset($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) return null;
    $f = $_FILES[$field];
    if ($f['error'] !== UPLOAD_ERR_OK || $f['size'] > 3 * 1024 * 1024) {
        $GLOBALS['UPLOAD_ERR'] = 'ছবি আপলোড হয়নি — ২ MB এর কম সাইজের ছবি দিন।';
        return null;
    }
    $info = @getimagesize($f['tmp_name']);
    $map = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
    if (!$info || !isset($map[$info[2]])) {
        $GLOBALS['UPLOAD_ERR'] = 'শুধু JPG, PNG বা WEBP ছবি দেওয়া যাবে।';
        return null;
    }
    if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
    $filename = 'prod_' . bin2hex(random_bytes(8)) . '.' . $map[$info[2]];
    if (!move_uploaded_file($f['tmp_name'], UPLOAD_DIR . '/' . $filename)) {
        $GLOBALS['UPLOAD_ERR'] = 'ছবি সেভ করা যায়নি — uploads ফোল্ডারের পারমিশন (755/775) দেখুন।';
        return null;
    }
    if ($oldImage && file_exists(UPLOAD_DIR . '/' . $oldImage)) @unlink(UPLOAD_DIR . '/' . $oldImage);
    return $filename;
}
