<?php
require_once __DIR__ . '/includes/functions.php';
$products = get_products();
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
if (empty($cart)) { header('Location: index.php'); exit; }

$items = [];
$total = 0;
foreach ($cart as $id => $qty) {
    foreach ($products as $p) {
        if ($p['id'] === $id) { $items[] = array_merge($p, ['qty' => $qty]); $total += $p['price'] * $qty; break; }
    }
}
if (empty($items)) { unset($_SESSION['cart']); header('Location: index.php'); exit; }

$error = '';
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$phoneRaw = isset($_POST['phone']) ? $_POST['phone'] : '';
$phone = normalize_phone($phoneRaw);
$address = isset($_POST['address']) ? trim($_POST['address']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['website'])) { header('Location: index.php'); exit; } // bot trap

    if (!valid_person_name($name)) {
        $error = 'অনুগ্রহ করে আপনার সঠিক নাম লিখুন।';
    } elseif (!valid_bd_phone($phone)) {
        $error = 'সঠিক মোবাইল নম্বর দিন (যেমন: 01712345678)। নাম বা ভুল নম্বর দিলে অর্ডার হবে না।';
    } elseif (mb_strlen($address, 'UTF-8') < 8) {
        $error = 'অনুগ্রহ করে সম্পূর্ণ ডেলিভারি ঠিকানা লিখুন।';
    } elseif (!order_rate_ok()) {
        $error = 'অল্প সময়ে অনেকগুলো অর্ডার করা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।';
    } else {
        // take the stock first (locked), so two buyers can't get the last item
        $stockOk = true;
        $lowName = '';
        update_json('products', function ($plist) use ($items, &$stockOk, &$lowName) {
            foreach ($items as $it) {
                foreach ($plist as $p) {
                    if ($p['id'] === $it['id'] && $p['stock'] < $it['qty']) { $stockOk = false; $lowName = $p['name']; }
                }
            }
            if (!$stockOk) return $plist;
            foreach ($plist as $i => $p) {
                foreach ($items as $it) {
                    if ($p['id'] === $it['id']) $plist[$i]['stock'] = $p['stock'] - $it['qty'];
                }
            }
            return $plist;
        });

        if (!$stockOk) {
            $error = '"' . $lowName . '" এর স্টক এখন কম। কার্টে পরিমাণ কমিয়ে আবার চেষ্টা করুন।';
        } else {
            $orderId = 'ORD' . strtoupper(bin2hex(random_bytes(4)));
            $orderItems = [];
            foreach ($items as $i) $orderItems[] = ['id' => $i['id'], 'name' => $i['name'], 'price' => $i['price'], 'qty' => $i['qty']];
            $now = date('Y-m-d H:i:s');
            $order = [
                'id' => $orderId,
                'items' => $orderItems,
                'total' => $total,
                'customer_name' => $name,
                'phone' => $phone,
                'address' => $address,
                'created_at' => $now,
                'status' => 'pending',
                'history' => [['status' => 'pending', 'at' => $now]],
            ];
            update_json('orders', function ($list) use ($order) { $list[] = $order; return $list; });

            unset($_SESSION['cart']);
            if (!isset($_SESSION['my_orders'])) $_SESSION['my_orders'] = [];
            $_SESSION['my_orders'][] = $orderId;
            header('Location: confirm.php?order=' . urlencode($orderId));
            exit;
        }
    }
}

$BASE = '';
include __DIR__ . '/includes/header.php';
?>
<h1 class="page-title">অর্ডার সম্পন্ন করুন</h1>
<div class="checkout-grid">
  <form method="post" class="form-card" autocomplete="on">
    <div class="form-group">
      <label>আপনার নাম</label>
      <input type="text" name="name" class="form-input" value="<?php echo h($name); ?>" placeholder="যেমন: রহিমা আক্তার" required>
    </div>
    <div class="form-group">
      <label>মোবাইল নম্বর</label>
      <input type="tel" name="phone" class="form-input" value="<?php echo h($phoneRaw); ?>" placeholder="01XXXXXXXXX" maxlength="16" required>
    </div>
    <div class="form-group">
      <label>ডেলিভারি ঠিকানা</label>
      <textarea name="address" class="form-input" placeholder="বাসা/রোড, এলাকা, থানা, জেলা" required><?php echo h($address); ?></textarea>
    </div>
    <input type="text" name="website" value="" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px;" aria-hidden="true">
    <?php if ($error): ?><div class="alert-error"><?php echo h($error); ?></div><?php endif; ?>
    <button type="submit" class="btn btn-primary btn-block">অর্ডার করুন — <?php echo taka($total); ?></button>
  </form>

  <div class="order-summary">
    <h3>অর্ডার সারসংক্ষেপ</h3>
    <?php foreach ($items as $it): ?>
      <div class="summary-row"><span><?php echo h($it['name']); ?> × <?php echo $it['qty']; ?></span><span><?php echo taka($it['price'] * $it['qty']); ?></span></div>
    <?php endforeach; ?>
    <div class="summary-total"><span>সর্বমোট</span><span><?php echo taka($total); ?></span></div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
