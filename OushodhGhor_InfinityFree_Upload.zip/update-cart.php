<?php
require_once __DIR__ . '/includes/functions.php';
$id = isset($_GET['id']) ? $_GET['id'] : '';
$action = isset($_GET['action']) ? $_GET['action'] : '';

$products = get_products();
$product = null;
foreach ($products as $p) { if ($p['id'] === $id) { $product = $p; break; } }

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

if ($product) {
    $cur = isset($_SESSION['cart'][$id]) ? $_SESSION['cart'][$id] : 0;
    if ($action === 'inc' && $cur < $product['stock']) {
        $_SESSION['cart'][$id] = $cur + 1;
    } elseif ($action === 'dec') {
        $cur--;
        if ($cur <= 0) unset($_SESSION['cart'][$id]); else $_SESSION['cart'][$id] = $cur;
    } elseif ($action === 'remove') {
        unset($_SESSION['cart'][$id]);
    }
}

header('Location: cart.php');
exit;
