<?php
require_once __DIR__ . '/includes/functions.php';
$orderId = isset($_GET['order']) ? $_GET['order'] : '';
$mine = isset($_SESSION['my_orders']) && in_array($orderId, $_SESSION['my_orders'], true);
$order = null;
if ($mine) {
    foreach (get_orders() as $o) { if ($o['id'] === $orderId) { $order = $o; break; } }
}
if (!$order) { header('Location: index.php'); exit; }

$settings = get_settings();
$waLink = null;
if (!empty($settings['admin_phone'])) {
    $phone = preg_replace('/[^0-9]/', '', $settings['admin_phone']);
    $lines = [
        'নতুন অর্ডার #' . $order['id'],
        'গ্রাহক: ' . $order['customer_name'],
        'ফোন: ' . $order['phone'],
        'ঠিকানা: ' . $order['address'],
        '',
        'পণ্যসমূহ:',
    ];
    foreach ($order['items'] as $it) $lines[] = '- ' . $it['name'] . ' x' . $it['qty'] . ' = ' . taka($it['price'] * $it['qty']);
    $lines[] = '';
    $lines[] = 'মোট মূল্য: ' . taka($order['total']);
    $waLink = 'https://wa.me/' . $phone . '?text=' . rawurlencode(implode("\n", $lines));
}

$BASE = '';
include __DIR__ . '/includes/header.php';
?>
<div class="confirm-box">
  <div class="confirm-icon">✓</div>
  <h1 class="page-title">ধন্যবাদ, অর্ডার সম্পন্ন হয়েছে</h1>
  <p class="muted">অর্ডার নম্বর (এটা সংরক্ষণ করে রাখুন)</p>
  <p class="order-id">#<?php echo h($order['id']); ?></p>

  <div class="order-summary" style="text-align:left;">
    <?php foreach ($order['items'] as $it): ?>
      <div class="summary-row"><span><?php echo h($it['name']); ?> × <?php echo $it['qty']; ?></span><span><?php echo taka($it['price'] * $it['qty']); ?></span></div>
    <?php endforeach; ?>
    <div class="summary-total"><span>সর্বমোট</span><span><?php echo taka($order['total']); ?></span></div>
  </div>

  <a href="track.php?order=<?php echo urlencode($order['id']); ?>" class="btn btn-primary btn-block" style="margin-top:16px;">📦 অর্ডার ট্র্যাক করুন</a>
  <?php if ($waLink): ?>
    <a href="<?php echo h($waLink); ?>" target="_blank" rel="noopener" class="btn btn-whatsapp btn-block" style="margin-top:10px;">WhatsApp-এ অর্ডারের বার্তা পাঠান</a>
  <?php endif; ?>
  <a href="index.php" class="btn btn-outline btn-block" style="margin-top:10px;">আরও কেনাকাটা করুন</a>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
