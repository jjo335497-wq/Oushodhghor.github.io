<?php http_response_code(404); exit; ?>
[
  {
    "id": "p1",
    "name": "প্যারাসিটামল ৫০০ মি.গ্রা. (১০ পাতা)",
    "category": "fever",
    "price": 25,
    "stock": 120,
    "desc": "জ্বর ও সাধারণ ব্যথায় দ্রুত আরাম দেয়",
    "image": "",
    "details": "Active ingredient: Paracetamol 500mg. Take 1 tablet every 6-8 hours after meals. Do not exceed 4 tablets in 24 hours. Keep away from children."
  },
  {
    "id": "p2",
    "name": "আইবুপ্রোফেন ট্যাবলেট",
    "category": "fever",
    "price": 40,
    "stock": 60,
    "desc": "পেশি ও গাঁটের ব্যথায় কার্যকর",
    "image": "",
    "details": ""
  },
  {
    "id": "p3",
    "name": "ব্যথানাশক জেল ৩০ গ্রাম",
    "category": "fever",
    "price": 120,
    "stock": 0,
    "desc": "বাহ্যিক ব্যবহারের জন্য ব্যথানাশক জেল",
    "image": "",
    "details": ""
  },
  {
    "id": "p4",
    "name": "কাশির সিরাপ ১০০ মি.লি.",
    "category": "cold",
    "price": 85,
    "stock": 45,
    "desc": "শুকনো ও ভেজা কাশিতে আরাম দেয়",
    "image": "",
    "details": "For dry and wet cough. Adults: 10ml three times a day after meals. Shake well before use. Store in a cool, dry place away from sunlight."
  },
  {
    "id": "p5",
    "name": "নাকের ড্রপ ১৫ মি.লি.",
    "category": "cold",
    "price": 60,
    "stock": 30,
    "desc": "বন্ধ নাক খুলতে সহায়ক",
    "image": "",
    "details": ""
  },
  {
    "id": "p6",
    "name": "গলা ব্যথার লজেন্স (১০টি)",
    "category": "cold",
    "price": 50,
    "stock": 80,
    "desc": "গলা ব্যথা ও খুসখুসে কাশিতে আরাম",
    "image": "",
    "details": ""
  },
  {
    "id": "p7",
    "name": "ভিটামিন সি ৫০০ মি.গ্রা. (৩০ ট্যাবলেট)",
    "category": "vitamin",
    "price": 180,
    "stock": 70,
    "desc": "রোগ প্রতিরোধ ক্ষমতা বাড়াতে সহায়ক",
    "image": "",
    "details": "Each tablet contains Vitamin C 500mg. Supports immune function and skin health. Take 1 tablet daily with food, or as directed by a physician."
  },
  {
    "id": "p8",
    "name": "মাল্টিভিটামিন ক্যাপসুল (৩০টি)",
    "category": "vitamin",
    "price": 320,
    "stock": 40,
    "desc": "দৈনন্দিন পুষ্টির ঘাটতি পূরণে",
    "image": "",
    "details": ""
  },
  {
    "id": "p9",
    "name": "ওমেগা-৩ ক্যাপসুল (৬০টি)",
    "category": "vitamin",
    "price": 450,
    "stock": 0,
    "desc": "হৃদযন্ত্রের সুস্থতায় সহায়ক",
    "image": "",
    "details": ""
  },
  {
    "id": "p10",
    "name": "বেবি ডায়াপার (মিডিয়াম, ৩০ পিস)",
    "category": "baby",
    "price": 650,
    "stock": 25,
    "desc": "দীর্ঘক্ষণ শুষ্ক ও আরামদায়ক",
    "image": "",
    "details": ""
  },
  {
    "id": "p11",
    "name": "বেবি লোশন ২০০ মি.লি.",
    "category": "baby",
    "price": 210,
    "stock": 35,
    "desc": "শিশুর কোমল ত্বকের যত্নে",
    "image": "",
    "details": ""
  },
  {
    "id": "p12",
    "name": "ওরস্যালাইন (১০ প্যাকেট)",
    "category": "baby",
    "price": 30,
    "stock": 150,
    "desc": "পানিশূন্যতা প্রতিরোধে সহায়ক",
    "image": "",
    "details": ""
  },
  {
    "id": "p13",
    "name": "ফেসওয়াশ ৭৫ মি.লি.",
    "category": "skin",
    "price": 150,
    "stock": 55,
    "desc": "তৈলাক্ত ও ব্রণপ্রবণ ত্বকের জন্য",
    "image": "",
    "details": ""
  },
  {
    "id": "p14",
    "name": "সানস্ক্রিন এসপিএফ ৫০",
    "category": "skin",
    "price": 380,
    "stock": 20,
    "desc": "রোদের ক্ষতি থেকে ত্বক রক্ষা করে",
    "image": "",
    "details": ""
  },
  {
    "id": "p15",
    "name": "ময়েশ্চারাইজার লোশন",
    "category": "skin",
    "price": 220,
    "stock": 0,
    "desc": "শুষ্ক ত্বকে সারাদিন আর্দ্রতা দেয়",
    "image": "",
    "details": ""
  },
  {
    "id": "p16",
    "name": "গ্লুকোমিটার (স্ট্রিপসহ)",
    "category": "diabetes",
    "price": 1450,
    "stock": 12,
    "desc": "ঘরে বসে রক্তে শর্করা পরীক্ষা করুন",
    "image": "",
    "details": ""
  },
  {
    "id": "p17",
    "name": "গ্লুকোমিটার স্ট্রিপ (৫০টি)",
    "category": "diabetes",
    "price": 850,
    "stock": 18,
    "desc": "নিয়মিত পরীক্ষার জন্য স্ট্রিপ",
    "image": "",
    "details": ""
  },
  {
    "id": "p18",
    "name": "ব্যান্ডেজ রোল (৪ ইঞ্চি)",
    "category": "firstaid",
    "price": 35,
    "stock": 90,
    "desc": "ক্ষত ঢেকে রাখতে ব্যবহৃত হয়",
    "image": "",
    "details": ""
  },
  {
    "id": "p19",
    "name": "এন্টিসেপটিক লিকুইড ১০০ মি.লি.",
    "category": "firstaid",
    "price": 95,
    "stock": 60,
    "desc": "ক্ষত জীবাণুমুক্ত রাখতে সহায়ক",
    "image": "",
    "details": ""
  },
  {
    "id": "p20",
    "name": "সার্জিক্যাল মাস্ক (৫০টি)",
    "category": "protection",
    "price": 180,
    "stock": 100,
    "desc": "নিরাপদ শ্বাস-প্রশ্বাসের জন্য",
    "image": "",
    "details": ""
  },
  {
    "id": "p21",
    "name": "হ্যান্ড স্যানিটাইজার ২০০ মি.লি.",
    "category": "protection",
    "price": 110,
    "stock": 75,
    "desc": "৯৯.৯% জীবাণু ধ্বংস করে",
    "image": "",
    "details": ""
  },
  {
    "id": "p22",
    "name": "ডিসপোজেবল গ্লাভস (১০ জোড়া)",
    "category": "protection",
    "price": 70,
    "stock": 0,
    "desc": "হাত সুরক্ষিত রাখতে ব্যবহৃত হয়",
    "image": "",
    "details": ""
  }
]