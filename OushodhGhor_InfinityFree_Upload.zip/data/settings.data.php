<?php http_response_code(404); exit; ?>
{
  "admin_phone": "2250795929990",
  "contact_phone": "+225 07 95 92 99 90"
}