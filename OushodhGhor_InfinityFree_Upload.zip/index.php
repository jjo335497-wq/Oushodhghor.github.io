<?php
require_once __DIR__ . '/includes/functions.php';
$products = get_products();
$categories = category_list();
$activeCat = isset($_GET['cat']) ? $_GET['cat'] : 'all';
$q = trim(isset($_GET['q']) ? $_GET['q'] : '');

$filtered = array_filter($products, function ($p) use ($activeCat, $q) {
    $matchCat = $activeCat === 'all' || $p['category'] === $activeCat;
    $matchSearch = $q === '' || mb_stripos($p['name'], $q) !== false || mb_stripos($p['desc'], $q) !== false;
    return $matchCat && $matchSearch;
});

$BASE = '';
include __DIR__ . '/includes/header.php';
?>
<form method="get" class="search-form">
  <input type="text" name="q" class="search-input" placeholder="মেডিসিন বা স্বাস্থ্যপণ্য খুঁজুন..." value="<?php echo htmlspecialchars($q); ?>">
  <?php if ($activeCat !== 'all'): ?><input type="hidden" name="cat" value="<?php echo htmlspecialchars($activeCat); ?>"><?php endif; ?>
</form>

<div class="category-chips">
  <a href="?<?php echo $q ? 'q=' . urlencode($q) . '&' : ''; ?>cat=all" class="chip <?php echo $activeCat === 'all' ? 'active' : ''; ?>">সব পণ্য</a>
  <?php foreach ($categories as $cid => $cat): ?>
    <a href="?<?php echo $q ? 'q=' . urlencode($q) . '&' : ''; ?>cat=<?php echo $cid; ?>" class="chip <?php echo $activeCat === $cid ? 'active' : ''; ?>"><?php echo $cat['name']; ?></a>
  <?php endforeach; ?>
</div>

<?php if (empty($filtered)): ?>
  <div class="empty-state">
    <p><?php echo $q ? '"' . htmlspecialchars($q) . '" নামে কোনো পণ্য নেই — অন্য শব্দে খুঁজে দেখুন।' : 'এই ক্যাটাগরিতে এখনো কোনো পণ্য যোগ করা হয়নি।'; ?></p>
  </div>
<?php else: ?>
<div class="product-grid">
  <?php foreach ($filtered as $p): ?>
    <div class="product-card">
      <div class="product-image"><?php echo product_image_html($p, 140); ?></div>
      <?php if ($p['stock'] <= 0): ?>
        <span class="stock-badge out">স্টক নেই</span>
      <?php elseif ($p['stock'] <= 5): ?>
        <span class="stock-badge low">মাত্র <?php echo $p['stock']; ?> টি বাকি</span>
      <?php endif; ?>
      <div class="product-name"><?php echo htmlspecialchars($p['name']); ?></div>
      <div class="product-desc"><?php echo htmlspecialchars($p['desc']); ?></div>
      <?php if (!empty($p['details'])): ?>
        <details class="product-details">
          <summary>আরও বিবরণ</summary>
          <p><?php echo nl2br(htmlspecialchars($p['details'])); ?></p>
        </details>
      <?php endif; ?>
      <div class="price"><?php echo taka($p['price']); ?></div>
      <?php if ($p['stock'] > 0): ?>
        <form method="post" action="add-to-cart.php">
          <input type="hidden" name="id" value="<?php echo htmlspecialchars($p['id']); ?>">
          <input type="hidden" name="return" value="<?php echo htmlspecialchars($_SERVER['REQUEST_URI']); ?>">
          <button type="submit" class="btn btn-primary btn-block">কার্টে যোগ করুন</button>
        </form>
      <?php else: ?>
        <button class="btn btn-disabled btn-block" disabled>স্টক নেই</button>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
