<?php
require_once __DIR__ . '/includes/functions.php';
$isPost = ($_SERVER['REQUEST_METHOD'] === 'POST');
$id = strtoupper(trim(isset($_REQUEST['order']) ? $_REQUEST['order'] : ''));
$id = ltrim($id, '#');
$phone = normalize_phone(isset($_POST['phone']) ? $_POST['phone'] : '');
$order = null;
$error = '';

if ($id !== '') {
    $found = null;
    foreach (get_orders() as $o) { if ($o['id'] === $id) { $found = $o; break; } }
    $mine = isset($_SESSION['my_orders']) && in_array($id, $_SESSION['my_orders'], true);
    $phoneOk = $isPost && $found && normalize_phone($found['phone']) === $phone;
    if ($found && ($mine || $phoneOk)) {
        $order = $found;
    } elseif ($isPost) {
        $error = 'এই অর্ডার নম্বর ও ফোন নম্বরের সাথে কোনো অর্ডার পাওয়া যায়নি। নম্বর দুটো আবার মিলিয়ে দেখুন।';
    }
}

$BASE = '';
include __DIR__ . '/includes/header.php';
$labels = status_labels();
?>
<div class="track-box">
  <h1 class="page-title">অর্ডার ট্র্যাক করুন</h1>
<?php if ($order): ?>
  <div class="order-summary">
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px;">
      <strong style="font-family:'JetBrains Mono',monospace;">#<?php echo h($order['id']); ?></strong>
      <span class="status-select status-<?php echo h($order['status']); ?>" style="font-size:12px;"><?php echo h($labels[$order['status']]); ?></span>
    </div>
    <p class="hint" style="margin:0;">অর্ডারের সময়: <?php echo h(fmt_time($order['created_at'])); ?></p>

    <?php if ($order['status'] === 'cancelled'): ?>
      <div class="alert-error" style="margin:14px 0;font-weight:600;">❌ এই অর্ডারটি বাতিল করা হয়েছে।</div>
    <?php else:
      $steps = track_steps();
      $idx = 0;
      foreach ($steps as $i => $s) { if ($s[0] === $order['status']) $idx = $i; }
    ?>
      <div class="timeline">
        <?php foreach ($steps as $i => $s):
          $cls = $i < $idx ? 'done' : ($i === $idx ? 'done current' : 'todo');
          $t = $i <= $idx ? order_step_time($order, $s[0]) : '';
        ?>
          <div class="tl-step <?php echo $cls; ?>">
            <div class="tl-dot"><?php echo $i <= $idx ? '✓' : ''; ?></div>
            <div>
              <div class="tl-label"><?php echo h($s[1]); ?></div>
              <div class="tl-sub"><?php echo h($s[2]); ?><?php echo $t ? ' • ' . h($t) : ''; ?></div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <h3>অর্ডার করা পণ্য</h3>
    <?php foreach ($order['items'] as $it): ?>
      <div class="summary-row"><span><?php echo h($it['name']); ?> × <?php echo $it['qty']; ?></span><span><?php echo taka($it['price'] * $it['qty']); ?></span></div>
    <?php endforeach; ?>
    <div class="summary-total"><span>সর্বমোট</span><span><?php echo taka($order['total']); ?></span></div>
    <p class="hint" style="margin:12px 0 0;">📍 <?php echo h($order['address']); ?></p>
  </div>
  <div style="display:flex;gap:8px;margin-top:12px;">
    <a href="track.php?order=<?php echo urlencode($order['id']); ?>" class="btn btn-outline" style="flex:1;">🔄 সর্বশেষ অবস্থা</a>
    <a href="track.php" class="btn btn-outline" style="flex:1;">অন্য অর্ডার খুঁজুন</a>
  </div>
<?php else: ?>
  <form method="post" class="form-card">
    <div class="form-group">
      <label>অর্ডার নম্বর</label>
      <input type="text" name="order" class="form-input" value="<?php echo h($id); ?>" placeholder="যেমন: ORD1A2B3C4D" required>
    </div>
    <div class="form-group">
      <label>অর্ডারের সময় দেওয়া মোবাইল নম্বর</label>
      <input type="tel" name="phone" class="form-input" placeholder="01XXXXXXXXX" required>
    </div>
    <?php if ($error): ?><div class="alert-error"><?php echo h($error); ?></div><?php endif; ?>
    <button type="submit" class="btn btn-primary btn-block">অর্ডারের অবস্থা দেখুন</button>
  </form>
<?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
