<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $pid = isset($_POST['id']) ? $_POST['id'] : '';
    if ($action === 'toggle') {
        update_json('products', function ($list) use ($pid) {
            foreach ($list as $i => $p) { if ($p['id'] === $pid) $list[$i]['stock'] = $p['stock'] > 0 ? 0 : 10; }
            return $list;
        });
    } elseif ($action === 'delete') {
        $img = '';
        update_json('products', function ($list) use ($pid, &$img) {
            $keep = [];
            foreach ($list as $p) {
                if ($p['id'] === $pid) { $img = isset($p['image']) ? $p['image'] : ''; } else { $keep[] = $p; }
            }
            return $keep;
        });
        if ($img && file_exists(UPLOAD_DIR . '/' . $img)) @unlink(UPLOAD_DIR . '/' . $img);
    }
    header('Location: products.php');
    exit;
}

$products = get_products();
$categories = category_list();
$BASE = '../';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/nav.php';
?>
<div class="admin-toolbar">
  <h1 class="page-title" style="margin:0;">পণ্যসমূহ</h1>
  <a href="product-add.php" class="btn btn-primary">+ নতুন পণ্য যোগ করুন</a>
</div>
<?php if (isset($_GET['updated'])): ?><div class="alert-success" style="margin-bottom:14px;">পরিবর্তন সংরক্ষণ হয়েছে — পণ্যটি এখন সবার কাছে দেখা যাচ্ছে।</div><?php endif; ?>
<div class="table-wrap">
<table class="admin-table">
  <thead><tr><th>ছবি</th><th>নাম</th><th>ক্যাটাগরি</th><th>দাম</th><th>স্টক</th><th>অ্যাকশন</th></tr></thead>
  <tbody>
  <?php foreach ($products as $p): ?>
    <tr>
      <td><div class="thumb"><?php echo product_image_html($p, 48); ?></div></td>
      <td><?php echo h($p['name']); ?></td>
      <td><?php echo isset($categories[$p['category']]) ? h($categories[$p['category']]['name']) : ''; ?></td>
      <td><?php echo taka($p['price']); ?></td>
      <td><?php echo (int)$p['stock']; ?></td>
      <td class="admin-actions">
        <a href="product-edit.php?id=<?php echo urlencode($p['id']); ?>" class="btn btn-outline btn-sm">সম্পাদনা</a>
        <form method="post" style="margin:0;">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="action" value="toggle">
          <input type="hidden" name="id" value="<?php echo h($p['id']); ?>">
          <button type="submit" class="btn btn-outline btn-sm"><?php echo $p['stock'] > 0 ? 'স্টক নেই করুন' : 'স্টকে আনুন'; ?></button>
        </form>
        <form method="post" style="margin:0;" onsubmit="return confirm('আপনি কি নিশ্চিত এই পণ্যটি মুছে ফেলতে চান?');">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="id" value="<?php echo h($p['id']); ?>">
          <button type="submit" class="btn btn-outline btn-sm btn-danger">মুছুন</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
