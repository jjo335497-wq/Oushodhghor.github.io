<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
$settings = get_settings();
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $adminPhone = preg_replace('/[^0-9]/', '', isset($_POST['admin_phone']) ? $_POST['admin_phone'] : '');
    $contact = trim(isset($_POST['contact_phone']) ? $_POST['contact_phone'] : '');
    $newPw = isset($_POST['new_password']) ? $_POST['new_password'] : '';
    $curPw = isset($_POST['current_password']) ? $_POST['current_password'] : '';

    if ($newPw !== '' && !password_verify($curPw, $settings['admin_password_hash'])) {
        $error = 'পাসওয়ার্ড বদলাতে হলে বর্তমান পাসওয়ার্ড সঠিকভাবে দিতে হবে।';
    } elseif ($newPw !== '' && strlen($newPw) < 8) {
        $error = 'নতুন পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।';
    } else {
        $hash = $newPw !== '' ? password_hash($newPw, PASSWORD_DEFAULT) : null;
        update_json('settings', function ($s) use ($adminPhone, $contact, $hash) {
            $s['admin_phone'] = $adminPhone;
            $s['contact_phone'] = $contact;
            if ($hash) $s['admin_password_hash'] = $hash;
            return $s;
        });
        $settings = get_settings();
        $success = 'সেটিংস সংরক্ষণ হয়েছে।';
    }
}

$BASE = '../';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/nav.php';
?>
<h1 class="page-title">সেটিংস</h1>
<?php if ($success): ?><div class="alert-success" style="margin-bottom:14px;"><?php echo h($success); ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert-error" style="margin-bottom:14px;"><?php echo h($error); ?></div><?php endif; ?>
<form method="post" class="form-card" style="max-width:520px;">
  <?php echo csrf_field(); ?>
  <div class="form-group">
    <label>WhatsApp নম্বর (অর্ডার নোটিফিকেশনের জন্য)</label>
    <input type="text" name="admin_phone" class="form-input" value="<?php echo h($settings['admin_phone']); ?>" placeholder="8801XXXXXXXXX">
    <p class="hint">দেশের কোডসহ শুধু সংখ্যা লিখুন।</p>
  </div>
  <div class="form-group">
    <label>যোগাযোগ নম্বর (ওয়েবসাইটে দেখানো হবে)</label>
    <input type="text" name="contact_phone" class="form-input" value="<?php echo h($settings['contact_phone']); ?>">
  </div>
  <div class="form-group">
    <label>পাসওয়ার্ড বদলাতে চাইলে — বর্তমান পাসওয়ার্ড</label>
    <input type="password" name="current_password" class="form-input" autocomplete="current-password">
  </div>
  <div class="form-group">
    <label>নতুন পাসওয়ার্ড (কমপক্ষে ৮ অক্ষর; না বদলালে খালি রাখুন)</label>
    <input type="password" name="new_password" class="form-input" autocomplete="new-password">
  </div>
  <button type="submit" class="btn btn-primary">সংরক্ষণ করুন</button>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
