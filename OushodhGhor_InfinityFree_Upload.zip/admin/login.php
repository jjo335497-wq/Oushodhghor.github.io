<?php
require_once __DIR__ . '/../includes/functions.php';
if (is_admin()) { header('Location: orders.php'); exit; }

$settings = get_settings();
$setup = empty($settings['admin_password_hash']); // first visit: owner chooses the password
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if ($setup) {
        $pw = isset($_POST['password']) ? $_POST['password'] : '';
        $pw2 = isset($_POST['password2']) ? $_POST['password2'] : '';
        if (strlen($pw) < 8) {
            $error = 'পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।';
        } elseif ($pw !== $pw2) {
            $error = 'দুটো পাসওয়ার্ড মিলছে না।';
        } else {
            $hash = password_hash($pw, PASSWORD_DEFAULT);
            update_json('settings', function ($s) use ($hash) { $s['admin_password_hash'] = $hash; return $s; });
            session_regenerate_id(true);
            $_SESSION['is_admin'] = true;
            header('Location: orders.php');
            exit;
        }
    } elseif (login_locked()) {
        $error = 'অনেকবার ভুল পাসওয়ার্ড দেওয়া হয়েছে। ১০ মিনিট পরে আবার চেষ্টা করুন।';
    } elseif (password_verify(isset($_POST['password']) ? $_POST['password'] : '', $settings['admin_password_hash'])) {
        login_clear();
        session_regenerate_id(true);
        $_SESSION['is_admin'] = true;
        header('Location: orders.php');
        exit;
    } else {
        login_fail();
        $error = 'পাসওয়ার্ড সঠিক নয়।';
    }
}

$BASE = '../';
include __DIR__ . '/../includes/header.php';
?>
<div class="login-box">
  <div class="confirm-icon">🔒</div>
  <h1 class="page-title"><?php echo $setup ? 'অ্যাডমিন পাসওয়ার্ড সেট করুন' : 'অ্যাডমিন লগইন'; ?></h1>
  <?php if ($setup): ?>
    <p class="hint" style="margin-bottom:12px;">এটা আপনার প্রথমবার। নিজের জন্য একটা শক্ত পাসওয়ার্ড (কমপক্ষে ৮ অক্ষর) দিন — এটা শুধু আপনি জানবেন।</p>
  <?php endif; ?>
  <?php if ($error): ?><div class="alert-error" style="margin-bottom:12px;"><?php echo h($error); ?></div><?php endif; ?>
  <form method="post" class="form-card">
    <?php echo csrf_field(); ?>
    <input type="password" name="password" class="form-input" placeholder="<?php echo $setup ? 'নতুন পাসওয়ার্ড' : 'পাসওয়ার্ড দিন'; ?>" autofocus required>
    <?php if ($setup): ?>
      <input type="password" name="password2" class="form-input" placeholder="পাসওয়ার্ডটি আবার লিখুন" required>
    <?php endif; ?>
    <button type="submit" class="btn btn-primary btn-block"><?php echo $setup ? 'পাসওয়ার্ড সেট করুন' : 'প্রবেশ করুন'; ?></button>
  </form>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
