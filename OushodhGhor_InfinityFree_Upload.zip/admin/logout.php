<?php
require_once __DIR__ . '/../includes/functions.php';
unset($_SESSION['is_admin']);
session_regenerate_id(true);
header('Location: login.php');
exit;
