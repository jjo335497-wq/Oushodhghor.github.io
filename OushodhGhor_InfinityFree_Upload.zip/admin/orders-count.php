<?php
require_once __DIR__ . '/../includes/functions.php';
if (!is_admin()) { http_response_code(403); exit; }
header('Content-Type: application/json');
header('Cache-Control: no-store');
$orders = get_orders();
$pending = 0;
foreach ($orders as $o) { if ($o['status'] === 'pending') $pending++; }
echo json_encode(['count' => count($orders), 'pending' => $pending]);
