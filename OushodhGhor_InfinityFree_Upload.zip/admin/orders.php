<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
$labels = status_labels();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $oid = isset($_POST['order_id']) ? $_POST['order_id'] : '';
    if ($action === 'status' && isset($labels[isset($_POST['status']) ? $_POST['status'] : ''])) {
        $newStatus = $_POST['status'];
        update_json('orders', function ($list) use ($oid, $newStatus) {
            foreach ($list as $i => $o) {
                if ($o['id'] === $oid && $o['status'] !== $newStatus) {
                    $list[$i]['status'] = $newStatus;
                    if (!isset($list[$i]['history'])) $list[$i]['history'] = [];
                    $list[$i]['history'][] = ['status' => $newStatus, 'at' => date('Y-m-d H:i:s')];
                }
            }
            return $list;
        });
    } elseif ($action === 'delete') {
        update_json('orders', function ($list) use ($oid) {
            return array_values(array_filter($list, function ($o) use ($oid) { return $o['id'] !== $oid; }));
        });
    } elseif ($action === 'clear_cancelled') {
        update_json('orders', function ($list) {
            return array_values(array_filter($list, function ($o) { return $o['status'] !== 'cancelled'; }));
        });
    }
    header('Location: orders.php');
    exit;
}

$orders = get_orders();
usort($orders, function ($a, $b) { return strcmp($b['created_at'], $a['created_at']); });
$cancelled = 0; $pending = 0;
foreach ($orders as $o) { if ($o['status'] === 'cancelled') $cancelled++; if ($o['status'] === 'pending') $pending++; }

$BASE = '../';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/nav.php';
?>
<div id="newBanner" class="new-banner" style="display:none;">🔔 নতুন অর্ডার এসেছে! <a href="orders.php">পেজ রিফ্রেশ করুন</a></div>
<h1 class="page-title">অর্ডারসমূহ <?php if ($pending): ?><span class="badge" style="position:static;display:inline-grid;"><?php echo $pending; ?> নতুন</span><?php endif; ?></h1>

<?php if ($cancelled > 0): ?>
  <form method="post" class="confirm-inline" onsubmit="return confirm('<?php echo $cancelled; ?> টি বাতিল অর্ডার একসাথে মুছে ফেলবেন? এটা আর ফেরানো যাবে না।');">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="action" value="clear_cancelled">
    <span><?php echo $cancelled; ?> টি অর্ডার "বাতিল" অবস্থায় আছে।</span>
    <button type="submit" class="btn btn-danger btn-sm">সব বাতিল অর্ডার মুছুন</button>
  </form>
<?php endif; ?>

<?php if (empty($orders)): ?>
  <div class="empty-state"><p>এখনো কোনো অর্ডার আসেনি। নতুন অর্ডার এলে এখানেই দেখা যাবে।</p></div>
<?php else: foreach ($orders as $o):
  $ph = normalize_phone($o['phone']);
  $wa = valid_bd_phone($ph) ? 'https://wa.me/88' . $ph : null;
?>
  <div class="order-card">
    <div class="order-head">
      <strong>#<?php echo h($o['id']); ?></strong>
      <span class="order-date"><?php echo h(fmt_time($o['created_at'])); ?></span>
      <form method="post" class="status-form">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="status">
        <input type="hidden" name="order_id" value="<?php echo h($o['id']); ?>">
        <select name="status" onchange="this.form.submit()" class="status-select status-<?php echo h($o['status']); ?>">
          <?php foreach ($labels as $key => $label): ?>
            <option value="<?php echo $key; ?>" <?php echo $o['status'] === $key ? 'selected' : ''; ?>><?php echo h($label); ?></option>
          <?php endforeach; ?>
        </select>
      </form>
      <form method="post" onsubmit="return confirm('এই অর্ডারটি মুছে ফেলবেন?');" style="margin:0;">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="order_id" value="<?php echo h($o['id']); ?>">
        <button type="submit" class="btn btn-outline btn-sm btn-danger" title="মুছুন">🗑️</button>
      </form>
    </div>
    <div class="order-body">
      <div><strong>গ্রাহক:</strong> <?php echo h($o['customer_name']); ?></div>
      <div><strong>ফোন:</strong> <a href="tel:<?php echo h($ph); ?>"><?php echo h($o['phone']); ?></a>
        <?php if ($wa): ?> • <a href="<?php echo h($wa); ?>" target="_blank" rel="noopener">WhatsApp</a><?php endif; ?></div>
      <div><strong>ঠিকানা:</strong> <?php echo h($o['address']); ?></div>
      <ul class="order-items">
        <?php foreach ($o['items'] as $it): ?>
          <li><?php echo h($it['name']); ?> × <?php echo $it['qty']; ?> — <?php echo taka($it['price'] * $it['qty']); ?></li>
        <?php endforeach; ?>
      </ul>
      <div class="order-total">মোট: <?php echo taka($o['total']); ?></div>
    </div>
  </div>
<?php endforeach; endif; ?>

<script>
var knownCount = <?php echo count($orders); ?>;
setInterval(function () {
  fetch('orders-count.php', { cache: 'no-store' })
    .then(function (r) { return r.json(); })
    .then(function (d) {
      if (d.count > knownCount) {
        document.getElementById('newBanner').style.display = 'flex';
        document.title = '🔔 নতুন অর্ডার!';
      }
    }).catch(function () {});
}, 20000);
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
