<?php $__current = basename($_SERVER['PHP_SELF']); ?>
<nav class="admin-nav">
  <a href="orders.php" class="<?php echo $__current === 'orders.php' ? 'active' : ''; ?>">অর্ডার</a>
  <a href="products.php" class="<?php echo in_array($__current, ['products.php', 'product-add.php', 'product-edit.php']) ? 'active' : ''; ?>">পণ্য</a>
  <a href="settings.php" class="<?php echo $__current === 'settings.php' ? 'active' : ''; ?>">সেটিংস</a>
  <a href="logout.php" class="logout-link">লগআউট</a>
</nav>
