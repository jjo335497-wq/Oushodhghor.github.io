<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
$id = isset($_GET['id']) ? $_GET['id'] : '';
$product = find_product($id);
if (!$product) { header('Location: products.php'); exit; }
$categories = category_list();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $name = trim(isset($_POST['name']) ? $_POST['name'] : '');
    $category = isset($_POST['category']) ? $_POST['category'] : $product['category'];
    if (!isset($categories[$category])) $category = $product['category'];
    $price = max(0, (float)(isset($_POST['price']) ? $_POST['price'] : 0));
    $stock = max(0, (int)(isset($_POST['stock']) ? $_POST['stock'] : 0));
    $desc = trim(isset($_POST['desc']) ? $_POST['desc'] : '');
    $details = trim(isset($_POST['details']) ? $_POST['details'] : '');

    if ($name === '') {
        $error = 'পণ্যের নাম আবশ্যক।';
    } else {
        $newImage = handle_image_upload('image', isset($product['image']) ? $product['image'] : '');
        if ($GLOBALS['UPLOAD_ERR'] !== '') {
            $error = $GLOBALS['UPLOAD_ERR'];
        } else {
            update_json('products', function ($list) use ($id, $name, $category, $price, $stock, $desc, $details, $newImage) {
                foreach ($list as $i => $p) {
                    if ($p['id'] === $id) {
                        $list[$i]['name'] = $name;
                        $list[$i]['category'] = $category;
                        $list[$i]['price'] = $price;
                        $list[$i]['stock'] = $stock;
                        $list[$i]['desc'] = $desc;
                        $list[$i]['details'] = $details;
                        if ($newImage) $list[$i]['image'] = $newImage;
                    }
                }
                return $list;
            });
            header('Location: products.php?updated=1');
            exit;
        }
    }
    $product = array_merge($product, ['name' => $name, 'price' => $price, 'stock' => $stock, 'desc' => $desc, 'details' => $details, 'category' => $category]);
}

$BASE = '../';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/nav.php';
?>
<h1 class="page-title">পণ্য সম্পাদনা করুন</h1>
<?php if ($error): ?><div class="alert-error" style="margin-bottom:14px;"><?php echo h($error); ?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data" class="form-card">
  <?php echo csrf_field(); ?>
  <div class="form-group"><label>বর্তমান ছবি</label><div class="current-image"><?php echo product_image_html($product, 100); ?></div></div>
  <div class="form-group"><label>নতুন ছবি আপলোড করে বদলে দিন (ঐচ্ছিক)</label><input type="file" name="image" accept=".jpg,.jpeg,.png,.webp"></div>
  <div class="form-group"><label>পণ্যের নাম</label><input type="text" name="name" class="form-input" value="<?php echo h($product['name']); ?>" required></div>
  <div class="form-group">
    <label>ক্যাটাগরি</label>
    <select name="category" class="form-input">
      <?php foreach ($categories as $cid => $cat): ?>
        <option value="<?php echo $cid; ?>" <?php echo $product['category'] === $cid ? 'selected' : ''; ?>><?php echo h($cat['name']); ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="form-row">
    <div class="form-group"><label>দাম (৳)</label><input type="number" step="0.01" min="0" name="price" class="form-input" value="<?php echo h($product['price']); ?>" required></div>
    <div class="form-group"><label>স্টক পরিমাণ</label><input type="number" min="0" name="stock" class="form-input" value="<?php echo h($product['stock']); ?>" required></div>
  </div>
  <div class="form-group"><label>সংক্ষিপ্ত বিবরণ (কার্ডে দেখা যাবে)</label><textarea name="desc" class="form-input"><?php echo h($product['desc']); ?></textarea></div>
  <div class="form-group"><label>আরও বিস্তারিত বিবরণ (ঐচ্ছিক)</label><textarea name="details" class="form-input" style="min-height:110px;"><?php echo h(isset($product['details']) ? $product['details'] : ''); ?></textarea></div>
  <div><button type="submit" class="btn btn-primary">সংরক্ষণ করুন</button> <a href="products.php" class="btn btn-outline">বাতিল</a></div>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
