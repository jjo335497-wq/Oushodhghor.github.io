<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();
$categories = category_list();
$error = '';
$v = ['name' => '', 'category' => 'fever', 'price' => '', 'stock' => '', 'desc' => '', 'details' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    foreach ($v as $k => $_) { $v[$k] = trim(isset($_POST[$k]) ? $_POST[$k] : ''); }
    if (!isset($categories[$v['category']])) $v['category'] = 'fever';
    $price = max(0, (float)$v['price']);
    $stock = max(0, (int)$v['stock']);

    if ($v['name'] === '') {
        $error = 'পণ্যের নাম আবশ্যক।';
    } else {
        $image = handle_image_upload('image');
        if ($GLOBALS['UPLOAD_ERR'] !== '') {
            $error = $GLOBALS['UPLOAD_ERR'];
        } else {
            $new = [
                'id' => 'p' . bin2hex(random_bytes(5)),
                'name' => $v['name'],
                'category' => $v['category'],
                'price' => $price,
                'stock' => $stock,
                'desc' => $v['desc'] !== '' ? $v['desc'] : 'বিস্তারিত তথ্য শীঘ্রই যোগ করা হবে',
                'details' => $v['details'],
                'image' => $image ? $image : '',
            ];
            update_json('products', function ($list) use ($new) { $list[] = $new; return $list; });
            header('Location: products.php?updated=1');
            exit;
        }
    }
}

$BASE = '../';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/nav.php';
?>
<h1 class="page-title">নতুন পণ্য যোগ করুন</h1>
<?php if ($error): ?><div class="alert-error" style="margin-bottom:14px;"><?php echo h($error); ?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data" class="form-card">
  <?php echo csrf_field(); ?>
  <div class="form-group">
    <label>পণ্যের ছবি (ঐচ্ছিক — JPG/PNG/WEBP, ২ MB এর কম)</label>
    <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp">
  </div>
  <div class="form-group">
    <label>পণ্যের নাম</label>
    <input type="text" name="name" class="form-input" value="<?php echo h($v['name']); ?>" required>
  </div>
  <div class="form-group">
    <label>ক্যাটাগরি</label>
    <select name="category" class="form-input">
      <?php foreach ($categories as $cid => $cat): ?>
        <option value="<?php echo $cid; ?>" <?php echo $v['category'] === $cid ? 'selected' : ''; ?>><?php echo h($cat['name']); ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="form-row">
    <div class="form-group"><label>দাম (৳)</label><input type="number" step="0.01" min="0" name="price" class="form-input" value="<?php echo h($v['price']); ?>" required></div>
    <div class="form-group"><label>স্টক পরিমাণ</label><input type="number" min="0" name="stock" class="form-input" value="<?php echo h($v['stock']); ?>" required></div>
  </div>
  <div class="form-group"><label>সংক্ষিপ্ত বিবরণ (কার্ডে দেখা যাবে)</label><textarea name="desc" class="form-input"><?php echo h($v['desc']); ?></textarea></div>
  <div class="form-group"><label>আরও বিস্তারিত বিবরণ (ঐচ্ছিক — ব্যবহারবিধি, উপাদান ইত্যাদি)</label><textarea name="details" class="form-input" style="min-height:110px;"><?php echo h($v['details']); ?></textarea></div>
  <div><button type="submit" class="btn btn-primary">পণ্য যোগ করুন</button> <a href="products.php" class="btn btn-outline">বাতিল</a></div>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
