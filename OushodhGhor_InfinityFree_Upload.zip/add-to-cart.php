<?php
require_once __DIR__ . '/includes/functions.php';
$id = isset($_POST['id']) ? $_POST['id'] : '';
$product = $id !== '' ? find_product($id) : null;

if ($product && $product['stock'] > 0) {
    if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
    $cur = isset($_SESSION['cart'][$id]) ? $_SESSION['cart'][$id] : 0;
    if ($cur < $product['stock']) $_SESSION['cart'][$id] = $cur + 1;
}

// only go back to a page on this same site (blocks redirect tricks)
$back = isset($_POST['return']) ? $_POST['return'] : 'index.php';
if (!preg_match('#^/[^/\\\\]#', $back) && $back !== 'index.php') $back = 'index.php';
header('Location: ' . $back);
exit;
